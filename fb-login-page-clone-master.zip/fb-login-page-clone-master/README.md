# fb-login-page-clone

https://pranavks.github.io/fb-login-page-clone/

A responsive clone of Facebook login page using HTML & CSS for computer screen and mobile screen.

Demo video :  
![](demo.gif)  
https://youtu.be/mEz7-aGkyYo

When previewing in computer, reduce the browser window size to view Mobile version.

When previewing in mobile, use 'Desktop Site' option in Chrome to view Desktop version.

Disclaimer : UI cloned for educational purposes only.
